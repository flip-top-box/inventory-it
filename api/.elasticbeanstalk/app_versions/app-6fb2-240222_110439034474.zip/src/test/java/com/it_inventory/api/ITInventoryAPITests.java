package com.it_inventory.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ITInventoryAPITests {

	@Test
	void contextLoads() {
	}

}
